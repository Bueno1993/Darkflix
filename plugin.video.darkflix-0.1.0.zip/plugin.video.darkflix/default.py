import sys
from urllib.parse import urlencode, parse_qs
import xbmc, xbmcgui, xbmcplugin

HANDLE = int(sys.argv[1])
BASE = sys.argv[0]
PARAMS = parse_qs(sys.argv[2][1:]) if len(sys.argv) > 2 else {}
CATEGORIES = ['TV brasileira', 'TV internacional', 'Filmes', 'Séries', 'Novelas', 'Esportes', 'Animes', 'Favoritos']

# URLs oficiais de mídia direta (HLS/DASH) podem ser cadastradas pelo próprio usuário.
# Sites comuns e páginas HTML não são reproduzíveis diretamente pelo Kodi.
SOURCES = []

def folder(label, action, value=''):
    url = BASE + '?' + urlencode({'action': action, 'value': value})
    item = xbmcgui.ListItem(label=label)
    item.setArt({'icon': 'DefaultFolder.png'})
    xbmcplugin.addDirectoryItem(HANDLE, url, item, True)

def notice(message):
    xbmcgui.Dialog().ok('DarkFlix', message)

def main():
    xbmcplugin.setPluginCategory(HANDLE, 'DarkFlix')
    xbmcplugin.setContent(HANDLE, 'videos')
    action = PARAMS.get('action', [''])[0]
    value = PARAMS.get('value', [''])[0]
    if action == 'category':
        found = [s for s in SOURCES if s.get('category') == value]
        if not found:
            folder('Nenhuma fonte cadastrada — veja o README', 'help')
        for source in found:
            url = BASE + '?' + urlencode({'action': 'play', 'value': source['url']})
            li = xbmcgui.ListItem(label=source['title'])
            li.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(HANDLE, url, li, False)
    elif action == 'play':
        if not value.startswith(('https://', 'http://')):
            notice('URL inválida.')
        else:
            li = xbmcgui.ListItem(path=value)
            xbmcplugin.setResolvedUrl(HANDLE, True, li)
        return
    elif action == 'help':
        notice('Versão inicial: as categorias estão prontas. Para reproduzir, configure URLs de mídia direta autorizadas em SOURCES no default.py e gere outro ZIP.')
        return
    else:
        for category in CATEGORIES:
            folder(category, 'category', category)
        folder('Sobre / Ajuda', 'help')
    xbmcplugin.endOfDirectory(HANDLE)

if __name__ == '__main__':
    main()
