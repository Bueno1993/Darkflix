# DarkFlix 0.1.0 — protótipo Kodi

Complemento Kodi 19+ (Python 3) para Xbox Series X e outras plataformas.

## Instalação
1. Copie o ZIP para um local acessível pelo Kodi (ou hospede-o no GitHub Releases e baixe-o no dispositivo).
2. No Kodi: Configurações > Complementos > Instalar de um arquivo ZIP.
3. Se necessário, habilite fontes desconhecidas apenas para instalar o ZIP que você criou e verificou.
4. Selecione `plugin.video.darkflix-0.1.0.zip` e abra DarkFlix em Complementos de vídeo.

## Estado atual
- Oito categorias e interface de navegação padrão Kodi.
- Nenhum canal, filme ou série está embutido; as categorias ficam vazias até cadastrar fontes autorizadas.
- O tema preto/vermelho customizado, favoritos persistentes, integração com serviços e repositório de atualização automática ainda NÃO estão implementados.
- Para cadastrar fontes, edite `SOURCES` em `default.py` com objetos como `{'title': 'Meu canal', 'category': 'TV brasileira', 'url': 'https://exemplo.com/stream.m3u8'}` (URL ilustrativa, não funcional). Gere o ZIP novamente.
- Links para páginas HTML e serviços com DRM não funcionam como streams diretos. Use complementos oficiais compatíveis quando disponíveis.

Este ZIP não altera o Brazuca Play nem a skin do Kodi.
